import { ApplicationSet } from './application-set';
// import { Agent } from 'http';
import { IntentConfirmation } from './intent-confirmation';

export class ApplicationData {

  private applicationSets: ApplicationSet[];
  private bulkApplicationNo: string;
  private channel: string;
  private country: string;
  private kvm: Map<string, string>;

}
