export class PrePayment {
  // TODO: Add fields
}
