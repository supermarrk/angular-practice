export class BasicPlan {

  // TODO: Add fields
}
