export class Remark {
  category: string[];
  kvm: Map<string, string>;
  text: string;
  type: string;
}
