export class PolicyOwner {
  private isOwner: string;
}
