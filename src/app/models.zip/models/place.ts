export class Place {
  street: string;
  province: string;
  city: string;
  country: string;
  zipcode: string;
}
