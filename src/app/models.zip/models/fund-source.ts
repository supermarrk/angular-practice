export class FundSource {
  sourceType: string; // description: business,salary, gift, remittance,others
  remarks: string;
}
