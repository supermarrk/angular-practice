import { PremiumComponent } from './premium-component';

export class SingleComponent extends PremiumComponent {
}
