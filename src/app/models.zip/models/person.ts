import { PersonBasicInfo } from './person-basic-info';
import { ContactMethod } from './contact-method';
import { Registration } from './registration';
import { IncomeSource } from './income-source';

export class Person {
  kvm: Map<string, string>;
  basicInfo: PersonBasicInfo;
  contactInfo: ContactMethod;
  registrations: Registration[];
  incomeSource: IncomeSource;
}
