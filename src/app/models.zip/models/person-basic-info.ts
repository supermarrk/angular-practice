import { Place } from './place';
import { Measurement } from './measurement';

export class PersonBasicInfo {

  salutation: string;
  firstName: string;
  middleName: string;
  lastName: string;
  alias: string;
  age: number;
  gender: string;
  dateOfBirth: string;
  birthPlace: Place;
  citizenship: string[];
  nationality: string;
  civilSttus: string[];
  smokerStatus: string;
  height: Measurement;
  weight: Measurement;
  weightAtBirth: Measurement;
}
