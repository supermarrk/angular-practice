import { Insured } from './insured';

import { PolicyOwner } from './policy-owner';
import { Owner } from '../owner';

export class AccountType {
  private insured: Insured;
  private owner: Owner;
}
