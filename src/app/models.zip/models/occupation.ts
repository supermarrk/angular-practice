export class Occupation {
  occupationType: string; // description: primary, secondary
  other: string;
  title: string;
  company: string;
  natureOfBusiness: string;
  tenure: string;
}
