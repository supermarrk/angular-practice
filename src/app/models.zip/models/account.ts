import { Person } from './person';

import { AccountType } from './account-type';

export class Account {

  private accountType: AccountType;
  private id: string;
  private kvm: Map<string, string>;
  private person: Person;
  private sequenceId: string;
}
