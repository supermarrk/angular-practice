export class Money {
  // TODO: Add fields
}
