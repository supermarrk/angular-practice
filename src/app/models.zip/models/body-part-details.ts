export class BodyPartDetails {
  // TODO: Add fields
}
