export class Email {
  emailType: EmailType;
  notifications: string[];
  emailAddress: string;
  sameEntityAsType: string;
}

export enum EmailType {
  primary,
  secondary
}
