export interface ErrorFE {
  codes: string[];
}
