export class PreviousProposalDetails {
  // TODO: Add fields
}
