export class ReferralAgent {
  private agentCode: string;
}
