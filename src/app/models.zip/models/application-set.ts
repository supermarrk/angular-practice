import { Remark } from './remark';

import { PremiumComponent } from './premium-component';
import { Account } from './account';
import { Application } from './application';
import { Agent } from './agent';

export class ApplicationSet {

  private accounts: Account[];
  private agentInfo: Agent;
  private applications: Application[];
  private calculationBasedate: string;
  private kvm: Map<string, string>;
  private operationMode: string;
  private planId: string;
  private planName: string;
  private planStatus: string;
  private policyType: string;
  private remarks: Remark[];
  private repApplicationNo: string;
  private validTermTo: string;
  private validTermFrom: string;
}
