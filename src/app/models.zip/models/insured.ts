export class Insured {
  applications: string[];
  kvm: Map<string, string>;
}
