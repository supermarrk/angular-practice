import { ReferralAgent } from './referral-agent';

export class Agent {

  private agencyBranchCode: string;
  private agencyCode: string;
  private agencySalesDepartmentCode: string;
  private agencyUserId: string;
  private headAgencyCode: string;
  private kvm: Map<string, string>;
  private operatorId: string;
  private referralAgents: Agent[];
}
