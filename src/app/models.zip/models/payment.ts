export class Payment {
  // TODO: Add fields
}
