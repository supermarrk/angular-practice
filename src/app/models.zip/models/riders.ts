export class Riders {
  // TODO: Add fields
}
