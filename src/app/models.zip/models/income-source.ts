import { Occupation } from './occupation';

import { FundSource } from './fund-source';

export class IncomeSource {
  occupations: Occupation[];
  fundSource: FundSource[];
  grossAnnualIncome: number;
}
