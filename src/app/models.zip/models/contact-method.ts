import { Phone } from './phone';
import { Address } from './address';
import { Email } from './email';
import { Fax } from './fax';

export class ContactMethod {

  phone: Phone[];
  address: Address[];
  email: Email[];
  fax: Fax[];
}
