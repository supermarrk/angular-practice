export class IntentConfirmation {
  // TODO: Add fields
}
