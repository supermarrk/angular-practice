export class Address {
  adressType: AddressType;
  preferredMailingAddress: string;
  sameAsAddressType: string;
  notifications: string[];
}

export enum AddressType {
  permanent,
  business,
  present
}

// export enum MliUiErrorType {
//   popup,
//   field,
//   none
//   }

//   export default class MliUiErrorTypeUtil {
//   static getErrorType(val: string) {
//   return val ? MliUiErrorType[val] : MliUiErrorType.field;
//   }
