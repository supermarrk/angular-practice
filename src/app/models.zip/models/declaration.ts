export interface Declaration {
  default: string;
}
