export class Phone {
  phoneType: PhoneType;
  notifications: string[];
  countryCode: string;
  areaCode: string;
  phoneNumber: string;
  countryISOCode: string;
  extension: string;
  sameAsEntityType: string;
}

export enum PhoneType {
  home,
  mobile,
  business,
  overseas
}
