import { TopUp } from '../top-up';

export abstract class PremiumComponent {
  public amount: number;
  public total: number;
  public topUpList: TopUp[];
}
