import { Premium } from './premium';

import { Money } from './money';

import { PrePayment } from './pre-payment';

import { BasicPlan } from './basic-plan';

import { Riders } from './riders';

import { PreviousProposalDetails } from './previous-proposal-details';

import { BodyPartDetails } from './body-part-details';
import { Payment } from './payment';
import { Declaration } from './declaration';
import { ErrorFE } from './error-fe';

export class Application {

  private agentCode: string;
  private applicationId: string;
  private createDate: string;

//  private declarations: string[]; // for clarification
  declarations: Declaration[];

  private documents: Document[];

//  private error: // for clarification
  error: ErrorFE;

  private expiryDate: string;
  private kvm: Map<string, string>;
  private lastModifiedDate: string;
  private packageCode: string;
  private policyNumber: string;
  private premium: Premium;
  private proposalId: string;
  private purposeOfinsurance: string[];
  private riskTypes: string[];
  private status: string;
  private type: string;
}
