import { AnnualComponent } from '../annual-component';
import { MonthlyComponent } from '../monthly-component';
import { QuarterlyComponent } from '../quarterly-component';
import { SemiComponent } from '../semi-component';
import { SingleComponent } from './single-component';

export class Premium {
  annualComponent: AnnualComponent;
  currency: string;
  currencyExchangeRate: 0;
  monthlyComponent: MonthlyComponent;
  quarterlyComponent: QuarterlyComponent;
  semiComponent: SemiComponent;
  singleComponent: SingleComponent;
}
