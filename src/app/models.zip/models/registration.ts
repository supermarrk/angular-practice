export class Registration {
  registrationType: string; // description: passport, social security, drivers license
  registrationId: string;
  expiryDate: string;
}
