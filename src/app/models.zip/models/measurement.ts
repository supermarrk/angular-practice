export class Measurement {
  unit: string;
  value: number;
}
