export class Fax {
  faxType: FaxType;
  notifications: string[];
  faxNumber: string;
}

export enum FaxType {
  home,
  mobile,
  business,
  overseas
}
